# curry.io - Order Ahead, Zero Wait Time

A revolutionary food pre-ordering platform that eliminates restaurant queues. Pre-order your favorite food and skip the wait. Fresh food, ready when you arrive.

## Project Overview

curry.io is a dual-experience MVP designed for pitching the concept of skip-the-queue food ordering:

- **Customer App**: Browse restaurants, browse menus, add items to cart, checkout with MTN MoMo (demo), track orders in real-time
- **Restaurant Admin Dashboard**: Manage incoming orders, track order status, view kitchen queue, manage menu availability
- **Unique Value Prop**: Compare walk-in wait time vs pre-order time to showcase time savings

## Features

### Customer App
- Landing page with "Skip the Queue" messaging
- Restaurant discovery with wait time comparison
- Fast checkout flow (3 steps: browse → cart → pay)
- Real-time order tracking with countdown timer
- Live order status updates
- Order history

### Admin Kitchen Dashboard
- Live order queue view organized by status (Pending → Confirmed → Prepping → Ready)
- Quick status management buttons
- Real-time order statistics
- Demo PIN-based authentication
- Mobile-responsive interface

### Design System
- **Primary Color**: Vibrant Orange (#FF6B35) - Speed & Energy
- **Secondary Color**: Deep Navy (#1E3A8A) - Trust & Reliability
- **Accent Colors**: Green for success, Red for urgent
- **Typography**: Geist Sans for all text
- **Mobile-First**: Optimized for portrait phone orientation

## Demo Credentials

Access the admin dashboard with these demo credentials:

| Restaurant | PIN |
|-----------|-----|
| Nando's Kampala | 1234 |
| KFC Kampala | 5678 |
| Mama Bena Rolex & Posho | 9012 |
| Cafe Java | 3456 |
| Burger Republic | 7890 |

**Note**: Demo mode uses PIN authentication only. All data is stored in browser localStorage.

## Tech Stack

- **Framework**: Next.js 16 (App Router)
- **UI**: React 19
- **Styling**: Tailwind CSS 4
- **Components**: shadcn/ui
- **Storage**: localStorage (client-side only)
- **Icons**: Lucide React
- **Fonts**: Geist (Google Fonts)

## Getting Started

### Installation

```bash
# Clone the repository
git clone <repo-url>

# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the app.

### Project Structure

```
app/
├── page.tsx                    # Landing page
├── restaurants/page.tsx        # Restaurant listing
├── restaurant/[id]/page.tsx    # Menu & ordering
├── checkout/page.tsx           # Payment (MTN MoMo demo)
├── orders/
│   ├── page.tsx               # Order history
│   └── [id]/page.tsx          # Order tracking
└── admin/
    ├── login/page.tsx         # Admin login
    └── dashboard/page.tsx     # Kitchen queue view

components/
├── restaurant-card.tsx         # Restaurant card with wait time
├── menu-item-card.tsx         # Menu item with add to cart
├── order-status-tracker.tsx   # Order tracking UI
└── admin-order-card.tsx       # Kitchen order card

lib/
├── types.ts                   # TypeScript interfaces
├── data.ts                    # Sample restaurant data
├── store.ts                   # localStorage management
└── demo-init.ts              # Demo order initialization
```

## Key Features for Pitch

### 1. Speed Focus
Every interaction is optimized for fast completion:
- 3-step checkout process
- One-page menu with categories
- Quick status buttons in admin
- Real-time countdown timers

### 2. Wait Time Comparison
Restaurant cards show:
- Current walk-in wait time (~45 mins)
- Pre-order time (~15 mins avg)
- Visual comparison to highlight value

### 3. Live Order Queue
Admin dashboard displays:
- Orders organized by status
- Color-coded by priority
- Quick action buttons
- Real-time stats

### 4. MTN MoMo Integration (Demo)
Shows payment flow with:
- Phone number input
- Amount display in UGX
- Instant confirmation
- Demo mode flag

### 5. Pre-seeded Demo Data
Includes:
- 5 realistic Ugandan restaurants
- ~35 menu items per restaurant
- Sample orders in various states (for admin view)
- Authentic menu items & pricing

## Usage for Pitch

### Show Customer Flow
1. Start at landing page (/ )
2. Click "Start Ordering Now"
3. Browse restaurants
4. Click "Skip the Queue" on any restaurant
5. Add items to cart
6. Go to checkout
7. Enter demo details, checkout with MTN MoMo
8. View order tracking page with live updates

### Show Admin Dashboard
1. Go to /admin/login
2. Select any restaurant
3. Use demo PIN (shown on page)
4. View live order queue
5. Click buttons to update order status
6. Watch stats update in real-time

## Customization

### Add Your Own Data
Edit `lib/data.ts` to:
- Add/modify restaurants
- Change menu items
- Update prices in UGX
- Adjust prep times

### Change Colors
Edit `app/globals.css` to modify:
- Primary color (currently Orange)
- Secondary color (currently Navy)
- Accent colors
- Theme variables

### Add Real Integrations
Currently using demo mode. To add real functionality:
- Replace localStorage with backend API
- Implement real MTN MoMo payments
- Add user authentication
- Set up real-time WebSocket updates

## Performance Optimizations

- Static data loading
- Client-side state management
- No external API calls
- Optimized images and assets
- Fast navigation with Next.js routing

## Mobile Responsiveness

Fully responsive design with:
- Portrait-first optimization
- Touch-friendly buttons
- Readable typography at all sizes
- Smooth scrolling and animations

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- iOS Safari 13+
- Android Chrome 90+

## Deployment

### Deploy to Vercel

```bash
# Push to GitHub
git push origin main

# Deploy via Vercel Dashboard
# or
vercel deploy
```

### Environment Variables

No environment variables required for demo mode.

For production, you would add:
```env
NEXT_PUBLIC_API_URL=your_api_url
MTN_MOMO_API_KEY=your_api_key
DATABASE_URL=your_database_url
```

## Future Enhancements

- Real backend with database
- Actual MTN MoMo payment integration
- User authentication and accounts
- Real-time WebSocket updates
- Push notifications
- Map integration for delivery
- Restaurant analytics dashboard
- Loyalty/rewards program

## Notes for Investors

This MVP demonstrates:
✅ Clean, modern UI with brand consistency
✅ Fast checkout process (major UX strength)
✅ Live order tracking that builds trust
✅ Dual-view system (customer & restaurant)
✅ Mobile-first design for Uganda market
✅ Real-looking data that tells the story
✅ "Skip the queue" value prop emphasized throughout
✅ Pre-seeded demo scenarios for easy pitching

Perfect for investor demos, user testing, and validation before investing in backend infrastructure.

## Support

For questions about the demo, refer to the inline code comments or reach out to the development team.

---

Made with curry.io - Skip the Queue, Order Ahead
