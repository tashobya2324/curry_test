'use client';

import { Order } from '@/lib/types';
import { updateOrderStatus } from '@/lib/store';
import { Clock, Check, AlertCircle, UtensilsCrossed } from 'lucide-react';
import { useState } from 'react';

interface AdminOrderCardProps {
  order: Order;
  onStatusChange: (orderId: string, status: string) => void;
}

export function AdminOrderCard({ order, onStatusChange }: AdminOrderCardProps) {
  const [isTransitioning, setIsTransitioning] = useState(false);

  const getNextStatus = () => {
    switch (order.status) {
      case 'pending':
        return 'confirmed';
      case 'confirmed':
        return 'prepping';
      case 'prepping':
        return 'ready';
      case 'ready':
        return 'picked_up';
      default:
        return null;
    }
  };

  const getStatusColor = () => {
    switch (order.status) {
      case 'pending':
        return 'border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-950/30';
      case 'confirmed':
        return 'border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/30';
      case 'prepping':
        return 'border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-950/30';
      case 'ready':
        return 'border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/30';
      default:
        return 'border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-950/30';
    }
  };

  const getStatusIcon = () => {
    switch (order.status) {
      case 'pending':
        return <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />;
      case 'confirmed':
        return <Check className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
      case 'prepping':
        return <UtensilsCrossed className="w-5 h-5 text-orange-600 dark:text-orange-400" />;
      case 'ready':
        return <Check className="w-5 h-5 text-green-600 dark:text-green-400" />;
      default:
        return <Clock className="w-5 h-5 text-gray-600 dark:text-gray-400" />;
    }
  };

  const getStatusLabel = () => {
    switch (order.status) {
      case 'pending':
        return 'New Order';
      case 'confirmed':
        return 'Confirmed';
      case 'prepping':
        return 'Preparing';
      case 'ready':
        return 'Ready for Pickup';
      default:
        return order.status;
    }
  };

  const handleStatusUpdate = async () => {
    const nextStatus = getNextStatus();
    if (!nextStatus) return;

    setIsTransitioning(true);
    updateOrderStatus(order.id, nextStatus as any);
    onStatusChange(order.id, nextStatus);
    setIsTransitioning(false);
  };

  const minsSinceOrder = Math.floor(
    (new Date().getTime() - new Date(order.createdAt).getTime()) / 60000
  );

  const nextStatus = getNextStatus();

  return (
    <div className={`border-2 rounded-lg p-4 transition-all ${getStatusColor()}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3 flex-1">
          {getStatusIcon()}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-bold text-foreground text-lg">
                Order #{order.orderNumber}
              </h3>
              <span className="inline-block px-3 py-1 bg-primary/20 text-primary rounded-full text-xs font-bold">
                {getStatusLabel()}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              Ordered {minsSinceOrder} min ago • {order.customerName}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total</p>
          <p className="text-lg font-bold text-primary">
            {order.totalPrice.toLocaleString()} UGX
          </p>
        </div>
      </div>

      {/* Items */}
      <div className="border-t border-current border-opacity-20 pt-3 mb-4">
        <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">
          Items
        </p>
        <div className="space-y-1">
          {order.items.map((item, idx) => (
            <div key={idx} className="flex justify-between text-sm">
              <span className="text-foreground">
                <span className="font-semibold">{item.quantity}x</span> {item.name}
              </span>
              <span className="text-muted-foreground">
                {(item.price * item.quantity).toLocaleString()} UGX
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Customer Info */}
      <div className="bg-black/5 dark:bg-white/5 rounded p-2 mb-4 text-sm">
        <p className="text-muted-foreground">Contact: {order.customerPhone}</p>
      </div>

      {/* Action Button */}
      {nextStatus && (
        <button
          onClick={handleStatusUpdate}
          disabled={isTransitioning}
          className="w-full py-2 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isTransitioning
            ? 'Updating...'
            : `Mark as ${
                nextStatus === 'confirmed'
                  ? 'Confirmed'
                  : nextStatus === 'prepping'
                    ? 'Prepping'
                    : nextStatus === 'ready'
                      ? 'Ready'
                      : 'Picked Up'
              }`}
        </button>
      )}
      {!nextStatus && (
        <div className="w-full py-2 px-3 bg-green-100 dark:bg-green-950/50 text-green-900 dark:text-green-200 rounded-lg font-semibold text-center text-sm">
          Completed
        </div>
      )}
    </div>
  );
}
