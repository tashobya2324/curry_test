'use client';

import { Order } from '@/lib/types';
import { Clock, CheckCircle, Zap, AlertCircle } from 'lucide-react';
import { useEffect, useState } from 'react';

interface OrderStatusTrackerProps {
  order: Order;
}

export function OrderStatusTracker({ order }: OrderStatusTrackerProps) {
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const ready = new Date(order.estimatedReadyTime);
      const diff = ready.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeRemaining('Ready now!');
        setIsReady(true);
      } else {
        const minutes = Math.floor(diff / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        setTimeRemaining(`${minutes}:${seconds.toString().padStart(2, '0')}`);
        setIsReady(false);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [order.estimatedReadyTime]);

  const getStatusIcon = () => {
    switch (order.status) {
      case 'ready':
        return <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />;
      case 'prepping':
        return <Zap className="w-6 h-6 text-orange-500" />;
      case 'confirmed':
        return <Clock className="w-6 h-6 text-primary" />;
      case 'pending':
        return <Clock className="w-6 h-6 text-muted-foreground" />;
      default:
        return <AlertCircle className="w-6 h-6 text-muted-foreground" />;
    }
  };

  const getStatusLabel = () => {
    switch (order.status) {
      case 'ready':
        return 'Ready for Pickup';
      case 'prepping':
        return 'Being Prepared';
      case 'confirmed':
        return 'Order Confirmed';
      case 'pending':
        return 'Pending Confirmation';
      case 'picked_up':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  };

  const statusSteps = [
    { status: 'pending', label: 'Ordered' },
    { status: 'confirmed', label: 'Confirmed' },
    { status: 'prepping', label: 'Preparing' },
    { status: 'ready', label: 'Ready' },
    { status: 'picked_up', label: 'Picked Up' },
  ];

  const currentStepIndex = statusSteps.findIndex(
    (s) => s.status === order.status
  );

  return (
    <div className="space-y-6">
      {/* Main Status */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl p-6 border border-primary/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {getStatusIcon()}
            <div>
              <p className="text-sm text-muted-foreground">Order Status</p>
              <p className="font-semibold text-foreground">
                {getStatusLabel()}
              </p>
            </div>
          </div>
          {order.status === 'ready' && (
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Time to pick up:</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                Now!
              </p>
            </div>
          )}
          {order.status !== 'ready' &&
            order.status !== 'picked_up' &&
            order.status !== 'cancelled' && (
              <div className="text-right">
                <p className="text-xs text-muted-foreground">Ready in:</p>
                <p className="text-2xl font-bold text-primary">
                  {timeRemaining}
                </p>
              </div>
            )}
        </div>
      </div>

      {/* Progress Steps */}
      <div className="space-y-3">
        <p className="text-sm font-semibold text-foreground">Order Progress</p>
        <div className="space-y-2">
          {statusSteps.map((step, index) => (
            <div key={step.status} className="flex items-center gap-3">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm transition-all ${
                  index <= currentStepIndex
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {index + 1}
              </div>
              <span
                className={`text-sm ${
                  index <= currentStepIndex
                    ? 'text-foreground font-medium'
                    : 'text-muted-foreground'
                }`}
              >
                {step.label}
              </span>
              {index <= currentStepIndex && (
                <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400 ml-auto" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Order Details */}
      <div className="border border-border rounded-lg p-4 space-y-3">
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wide">
            Order Number
          </p>
          <p className="text-lg font-bold text-primary">
            {order.orderNumber}
          </p>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-3 border-t border-border/50">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Restaurant</p>
            <p className="font-medium text-sm">{order.restaurantName}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Total</p>
            <p className="font-semibold text-primary text-sm">
              {order.totalPrice.toLocaleString()} UGX
            </p>
          </div>
        </div>
      </div>

      {order.status === 'ready' && (
        <div className="bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-lg p-4 text-center">
          <p className="text-sm font-semibold text-green-700 dark:text-green-300">
            Your order is ready! Head to the restaurant to pick it up.
          </p>
        </div>
      )}
    </div>
  );
}
