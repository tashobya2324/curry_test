'use client';

import { MenuItem } from '@/lib/types';
import { Clock, Plus } from 'lucide-react';
import { useState } from 'react';

interface MenuItemCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem, quantity: number) => void;
}

export function MenuItemCard({ item, onAddToCart }: MenuItemCardProps) {
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    onAddToCart(item, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
    setQuantity(1);
  };

  return (
    <div className="rounded-lg border border-border bg-card p-4 hover:shadow-md transition-shadow">
      {/* Item Header */}
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <h4 className="font-semibold text-foreground text-sm">
            {item.name}
          </h4>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
            {item.description}
          </p>
        </div>
      </div>

      {/* Price and Prep Time */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3.5 h-3.5" />
          <span>{item.prepTime} min</span>
        </div>
        <span className="font-bold text-primary text-sm">
          {item.price.toLocaleString()} UGX
        </span>
      </div>

      {/* Quantity and Add Button */}
      <div className="flex items-center gap-2 mt-3">
        <div className="flex items-center border border-border rounded-lg">
          <button
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="w-8 h-8 flex items-center justify-center text-muted-foreground hover:bg-muted/50 transition-colors"
          >
            -
          </button>
          <span className="w-8 text-center text-sm font-medium">
            {quantity}
          </span>
          <button
            onClick={() => setQuantity(quantity + 1)}
            className="w-8 h-8 flex items-center justify-center text-muted-foreground hover:bg-muted/50 transition-colors"
          >
            +
          </button>
        </div>
        <button
          onClick={handleAdd}
          disabled={!item.available}
          className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-2 ${
            added
              ? 'bg-green-600 dark:bg-green-500 text-white'
              : item.available
                ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                : 'bg-muted text-muted-foreground cursor-not-allowed'
          }`}
        >
          <Plus className="w-4 h-4" />
          {added ? 'Added!' : 'Add'}
        </button>
      </div>

      {!item.available && (
        <p className="text-xs text-destructive mt-2 text-center font-medium">
          Unavailable
        </p>
      )}
    </div>
  );
}
