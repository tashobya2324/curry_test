import Link from 'next/link';
import { Restaurant } from '@/lib/types';
import { Star, Clock } from 'lucide-react';

interface RestaurantCardProps {
  restaurant: Restaurant;
  waitTime?: number; // simulated current wait time in minutes
}

export function RestaurantCard({
  restaurant,
  waitTime = 45,
}: RestaurantCardProps) {
  return (
    <Link href={`/restaurant/${restaurant.id}`}>
      <div className="group cursor-pointer rounded-xl border border-border bg-card overflow-hidden hover:shadow-lg transition-all">
        {/* Image Placeholder */}
        <div className="h-32 bg-gradient-to-br from-primary to-accent opacity-20 flex items-center justify-center group-hover:opacity-30 transition-all">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary opacity-40">
              {restaurant.name.charAt(0)}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Header */}
          <div className="flex items-start justify-between mb-2">
            <h3 className="font-semibold text-foreground line-clamp-1">
              {restaurant.name}
            </h3>
            <div className="flex items-center gap-1 text-sm">
              <Star className="w-4 h-4 fill-accent text-accent" />
              <span className="font-medium">{restaurant.rating}</span>
            </div>
          </div>

          {/* Cuisine Type */}
          <p className="text-xs text-muted-foreground mb-3">
            {restaurant.cuisineType}
          </p>

          {/* Wait Time Comparison */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                <span>Walk-in wait:</span>
              </div>
              <span className="font-semibold text-destructive">
                ~{waitTime} min
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                <span>Pre-order:</span>
              </div>
              <span className="font-semibold text-green-600 dark:text-green-400">
                ~{restaurant.avgPrepTime} min
              </span>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-4 pt-3 border-t border-border">
            <button className="w-full py-2 px-3 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors">
              Skip the Queue
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
}
