import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'curry.io - Skip the Queue, Order Ahead',
  description: 'Pre-order your favorite food and skip the restaurant queue. Fresh food, ready when you arrive. Available in Kampala, Uganda.',
  keywords: 'food delivery, pre-order, skip queue, restaurants, Kampala, Uganda, MTN MoMo',
  creator: 'curry.io',
  generator: 'v0.app',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0f0f0f' },
  ],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'curry.io - Skip the Queue',
    description: 'Pre-order food ahead and pick up instantly',
    type: 'website',
    locale: 'en_UG',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <DemoInitializer />
        {children}
        <Analytics />
      </body>
    </html>
  )
}

'use client'

import { useEffect } from 'react'
import { initializeDemoData } from '@/lib/demo-init'

function DemoInitializer() {
  useEffect(() => {
    initializeDemoData()
  }, [])
  
  return null
}
