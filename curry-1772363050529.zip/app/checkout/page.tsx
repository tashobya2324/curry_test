'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getCart, createOrder, getMaxPrepTime } from '@/lib/store';
import { CartItem } from '@/lib/types';
import { ArrowLeft, AlertCircle, Smartphone, Check } from 'lucide-react';

export default function CheckoutPage() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [restaurantId, setRestaurantId] = useState('');
  const [restaurantName, setRestaurantName] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('mtn');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderCreated, setOrderCreated] = useState(false);
  const [newOrderId, setNewOrderId] = useState('');

  useEffect(() => {
    const cart = getCart();
    if (!cart || cart.items.length === 0) {
      router.push('/restaurants');
      return;
    }

    setCartItems(cart.items);
    const firstItem = cart.items[0];
    setRestaurantId(cart.restaurantId);

    // Get restaurant info
    import('@/lib/data').then(({ restaurants }) => {
      const restaurant = restaurants.find((r) => r.id === cart.restaurantId);
      if (restaurant) {
        setRestaurantName(restaurant.name);
      }
    });
  }, [router]);

  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const maxPrepTime = Math.max(
    ...cartItems.map((item) => item.prepTime)
  );

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim() || !customerPhone.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    try {
      const order = createOrder(
        restaurantId,
        restaurantName,
        customerPhone,
        customerName
      );
      setNewOrderId(order.id);
      setOrderCreated(true);

      // Redirect after showing confirmation
      setTimeout(() => {
        router.push(`/orders/${order.id}`);
      }, 2000);
    } catch (error) {
      alert('Error creating order. Please try again.');
      setIsProcessing(false);
    }
  };

  if (orderCreated) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center space-y-6 animate-in fade-in">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto">
            <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Order Confirmed!
            </h1>
            <p className="text-muted-foreground">
              Your order has been placed successfully.
            </p>
          </div>
          <div className="text-left space-y-2 p-4 bg-card border border-border rounded-lg">
            <p className="text-sm text-muted-foreground">Order ID</p>
            <p className="text-lg font-bold text-primary break-all">
              {newOrderId}
            </p>
          </div>
          <p className="text-sm text-muted-foreground">
            Redirecting to order tracking...
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-foreground mb-8">
          Order Checkout
        </h1>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <form onSubmit={handleCheckout} className="md:col-span-2 space-y-6">
            {/* Customer Info */}
            <div className="space-y-4 border border-border rounded-lg p-6">
              <h2 className="font-semibold text-foreground text-lg">
                Delivery Information
              </h2>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="John Doe"
                  className="w-full px-4 py-2 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+256 700 123 456"
                  className="w-full px-4 py-2 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  required
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-4 border border-border rounded-lg p-6">
              <h2 className="font-semibold text-foreground text-lg">
                Payment Method
              </h2>

              <label className="flex items-center gap-3 p-4 border-2 border-primary rounded-lg cursor-pointer bg-primary/5">
                <input
                  type="radio"
                  name="payment"
                  value="mtn"
                  checked={paymentMethod === 'mtn'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-4 h-4"
                />
                <div className="flex-1">
                  <Smartphone className="w-5 h-5 text-primary mb-1" />
                  <p className="font-semibold text-foreground text-sm">
                    MTN Mobile Money
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Pay via MTN MoMo for instant confirmation
                  </p>
                </div>
              </label>

              <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-blue-900 dark:text-blue-200">
                    Demo mode: Payment will be instantly approved for testing
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className="w-full py-4 bg-primary text-primary-foreground rounded-lg font-bold text-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? 'Processing...' : 'Confirm Order'}
            </button>
          </form>

          {/* Order Summary */}
          <div className="space-y-6">
            {/* Restaurant Info */}
            <div className="border border-border rounded-lg p-4 space-y-3">
              <p className="text-sm text-muted-foreground">Restaurant</p>
              <p className="font-bold text-foreground">{restaurantName}</p>
            </div>

            {/* Order Items */}
            <div className="border border-border rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-foreground">Your Order</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {cartItems.map((item) => (
                  <div
                    key={item.menuItemId}
                    className="flex justify-between text-sm"
                  >
                    <div>
                      <p className="font-medium text-foreground">
                        {item.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        x {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium text-foreground">
                      {(item.price * item.quantity).toLocaleString()} UGX
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing Summary */}
            <div className="border-t border-border pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground font-medium">
                  {totalPrice.toLocaleString()} UGX
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Service Fee</span>
                <span className="text-foreground font-medium">Free</span>
              </div>
              <div className="border-t border-border/50 pt-2 mt-2 flex justify-between">
                <span className="font-semibold text-foreground">Total</span>
                <span className="text-lg font-bold text-primary">
                  {totalPrice.toLocaleString()} UGX
                </span>
              </div>
            </div>

            {/* Ready Time */}
            <div className="bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-lg p-4 text-center">
              <p className="text-xs text-muted-foreground mb-1">Ready in</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                ~{maxPrepTime} min
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Estimate from order confirmation
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
