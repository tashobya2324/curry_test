'use client';

import { RestaurantCard } from '@/components/restaurant-card';
import { restaurants } from '@/lib/data';
import { Search } from 'lucide-react';
import { useState, useMemo } from 'react';
import Link from 'next/link';

export default function RestaurantsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState<string | null>(null);

  // Get unique cuisines
  const cuisines = useMemo(
    () => [...new Set(restaurants.map((r) => r.cuisineType))],
    []
  );

  // Filter restaurants
  const filteredRestaurants = useMemo(() => {
    return restaurants.filter((r) => {
      const matchesSearch =
        r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCuisine =
        !selectedCuisine || r.cuisineType === selectedCuisine;

      return matchesSearch && matchesCuisine;
    });
  }, [searchTerm, selectedCuisine]);

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-primary">
            curry.io
          </Link>
          <Link
            href="/orders"
            className="text-sm px-4 py-2 rounded-lg hover:bg-muted/50 transition-colors"
          >
            My Orders
          </Link>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Search Section */}
        <div className="space-y-4 mb-8">
          <h1 className="text-3xl font-bold text-foreground">
            Skip the Queue
          </h1>
          <p className="text-muted-foreground">
            Browse restaurants and order ahead for instant pickup
          </p>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search restaurants, cuisines..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-card border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 text-foreground placeholder-muted-foreground"
            />
          </div>

          {/* Cuisine Filters */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCuisine(null)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                selectedCuisine === null
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/70'
              }`}
            >
              All
            </button>
            {cuisines.map((cuisine) => (
              <button
                key={cuisine}
                onClick={() => setSelectedCuisine(cuisine)}
                className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                  selectedCuisine === cuisine
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/70'
                }`}
              >
                {cuisine}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        {filteredRestaurants.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-4 mb-12">
            {filteredRestaurants.map((restaurant) => (
              <RestaurantCard
                key={restaurant.id}
                restaurant={restaurant}
                waitTime={45 + Math.random() * 30}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No restaurants found</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCuisine(null);
              }}
              className="mt-4 px-4 py-2 text-primary hover:underline text-sm"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
