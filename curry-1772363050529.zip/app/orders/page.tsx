'use client';

import Link from 'next/link';
import { getAllOrders } from '@/lib/store';
import { useState, useEffect } from 'react';
import { Order } from '@/lib/types';
import { Clock, MapPin, CheckCircle } from 'lucide-react';

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadOrders = () => {
      const allOrders = getAllOrders();
      setOrders(allOrders.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
      setIsLoading(false);
    };

    loadOrders();

    // Refresh every 5 seconds
    const interval = setInterval(loadOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  const activeOrders = orders.filter(
    (o) => !['picked_up', 'cancelled'].includes(o.status)
  );
  const pastOrders = orders.filter((o) =>
    ['picked_up', 'cancelled'].includes(o.status)
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready':
        return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950/30';
      case 'prepping':
        return 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/30';
      case 'confirmed':
        return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/30';
      case 'pending':
        return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-950/30';
      case 'picked_up':
        return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950/30';
      default:
        return 'text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-950/30';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'ready':
        return 'Ready for Pickup';
      case 'prepping':
        return 'Being Prepared';
      case 'confirmed':
        return 'Confirmed';
      case 'pending':
        return 'Pending';
      case 'picked_up':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading orders...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-primary">
            curry.io
          </Link>
          <Link
            href="/restaurants"
            className="text-sm px-4 py-2 rounded-lg hover:bg-muted/50 transition-colors"
          >
            Order Now
          </Link>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-foreground mb-8">My Orders</h1>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground mb-6">No orders yet</p>
            <Link
              href="/restaurants"
              className="inline-block px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              Start Your First Order
            </Link>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Active Orders */}
            {activeOrders.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-foreground">
                  Active Orders ({activeOrders.length})
                </h2>
                <div className="grid gap-4">
                  {activeOrders.map((order) => (
                    <Link
                      key={order.id}
                      href={`/orders/${order.id}`}
                      className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow bg-card"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-foreground">
                              {order.restaurantName}
                            </h3>
                            <span
                              className={`text-xs px-2 py-1 rounded-full font-medium ${getStatusColor(
                                order.status
                              )}`}
                            >
                              {getStatusLabel(order.status)}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Order #{order.orderNumber}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary text-lg">
                            {order.totalPrice.toLocaleString()} UGX
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {order.items.length} items
                          </p>
                        </div>
                      </div>

                      {/* Items Preview */}
                      <div className="text-sm text-muted-foreground mb-3 line-clamp-1">
                        {order.items
                          .map((item) => `${item.quantity}x ${item.name}`)
                          .join(', ')}
                      </div>

                      {/* Status Bar */}
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-primary" />
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                            style={{
                              width: order.status === 'pending' ? '25%' : 
                                     order.status === 'confirmed' ? '50%' :
                                     order.status === 'prepping' ? '75%' : '100%'
                            }}
                          />
                        </div>
                        {order.status === 'ready' ? (
                          <span className="text-xs font-bold text-green-600 dark:text-green-400">
                            Ready Now
                          </span>
                        ) : (
                          <span className="text-xs font-semibold text-primary">
                            ~{new Date(order.estimatedReadyTime).getMinutes() - new Date().getMinutes()}m
                          </span>
                        )}
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Past Orders */}
            {pastOrders.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-foreground">
                  Past Orders ({pastOrders.length})
                </h2>
                <div className="grid gap-4">
                  {pastOrders.map((order) => (
                    <Link
                      key={order.id}
                      href={`/orders/${order.id}`}
                      className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow bg-card/50 opacity-75"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-foreground">
                              {order.restaurantName}
                            </h3>
                            {order.status === 'picked_up' && (
                              <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Order #{order.orderNumber} •{' '}
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-foreground">
                            {order.totalPrice.toLocaleString()} UGX
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {order.items.length} items
                          </p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Bottom CTA */}
        {orders.length > 0 && (
          <div className="mt-8 text-center">
            <Link
              href="/restaurants"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
            >
              Order Again
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}
