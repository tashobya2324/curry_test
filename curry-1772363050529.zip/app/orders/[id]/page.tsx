'use client';

import { useEffect, useState } from 'react';
import { getOrder } from '@/lib/store';
import { Order } from '@/lib/types';
import { OrderStatusTracker } from '@/components/order-status-tracker';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function OrderTrackingPage({ params }: PageProps) {
  const { id } = (params as any);
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadOrder = async () => {
      const foundOrder = getOrder(id);
      setOrder(foundOrder);
      setIsLoading(false);

      // Simulate order status updates
      if (foundOrder && foundOrder.status === 'pending') {
        setTimeout(() => {
          const updatedOrder = getOrder(id);
          if (updatedOrder && updatedOrder.status === 'pending') {
            // In a real app, this would come from server updates
            setOrder({ ...updatedOrder, status: 'confirmed' });
          }
        }, 3000);
      }
    };

    loadOrder();
  }, [id]);

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading order...</p>
        </div>
      </main>
    );
  }

  if (!order) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Order not found</p>
          <Link href="/orders" className="text-primary hover:underline">
            Back to orders
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center">
          <Link
            href="/orders"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </Link>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-8 pb-20">
        <h1 className="text-3xl font-bold text-foreground mb-8">
          Track Your Order
        </h1>

        {/* Main Tracker */}
        <OrderStatusTracker order={order} />

        {/* Order Items */}
        <div className="mt-8 border border-border rounded-lg p-6">
          <h2 className="font-semibold text-foreground text-lg mb-4">
            Order Items
          </h2>
          <div className="space-y-3">
            {order.items.map((item, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center pb-3 border-b border-border/50 last:border-0"
              >
                <div>
                  <p className="font-medium text-foreground">{item.name}</p>
                  <p className="text-sm text-muted-foreground">
                    Qty: {item.quantity}
                  </p>
                </div>
                <p className="font-semibold text-foreground">
                  {(item.price * item.quantity).toLocaleString()} UGX
                </p>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="mt-4 pt-4 border-t border-border flex justify-between items-center">
            <p className="font-semibold text-foreground">Total Amount</p>
            <p className="text-xl font-bold text-primary">
              {order.totalPrice.toLocaleString()} UGX
            </p>
          </div>
        </div>

        {/* Help Section */}
        <div className="mt-8 border border-border rounded-lg p-6 bg-card/50">
          <h3 className="font-semibold text-foreground mb-3">
            Need Help?
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Call the restaurant directly to get the latest update on your order:
          </p>
          <div className="bg-card border border-border rounded-lg p-3 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Restaurant Contact</p>
              <p className="font-semibold text-foreground">+256 701 234 567</p>
            </div>
            <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors text-sm">
              Call Now
            </button>
          </div>
        </div>

        {/* Continue Shopping */}
        <div className="mt-8">
          <Link
            href="/restaurants"
            className="block text-center px-6 py-3 border border-border rounded-lg font-medium text-foreground hover:bg-muted/50 transition-colors"
          >
            Order from Another Restaurant
          </Link>
        </div>
      </div>
    </main>
  );
}
