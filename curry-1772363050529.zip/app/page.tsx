import Link from 'next/link';
import { Zap, Clock, TrendingUp } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-sm border-b border-border z-50">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            curry.io
          </h1>
          <Link
            href="/orders"
            className="text-sm px-4 py-2 rounded-lg hover:bg-muted/50 transition-colors"
          >
            My Orders
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-20 pb-12 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Main Hero */}
          <div className="text-center space-y-8 py-12 md:py-20">
            <div className="space-y-4">
              <div className="inline-block px-4 py-2 bg-primary/10 rounded-full border border-primary/30">
                <p className="text-sm font-semibold text-primary">
                  Skip the Queue Revolution
                </p>
              </div>
              <h2 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Order Ahead,{' '}
                <span className="text-transparent bg-gradient-to-r from-primary to-accent bg-clip-text">
                  Zero Wait Time
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Pre-order your favorite food and skip the restaurant queue. Fresh
                food, ready when you arrive.
              </p>
            </div>

            {/* CTA Button */}
            <div className="pt-6">
              <Link
                href="/restaurants"
                className="inline-block px-8 py-4 bg-gradient-to-r from-primary to-accent text-primary-foreground font-bold text-lg rounded-full hover:shadow-lg transition-all hover:scale-105"
              >
                Start Ordering Now
              </Link>
            </div>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 py-16">
            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-foreground text-lg">Fast & Easy</h3>
              <p className="text-muted-foreground text-sm">
                Order in seconds with our streamlined checkout process
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-foreground text-lg">
                Live Tracking
              </h3>
              <p className="text-muted-foreground text-sm">
                Track your order in real-time with accurate ready times
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-foreground text-lg">
                More Restaurants
              </h3>
              <p className="text-muted-foreground text-sm">
                Hundreds of restaurants across Kampala and beyond
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="border-t border-b border-border py-12">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div>
                <p className="text-3xl font-bold text-primary">45+</p>
                <p className="text-sm text-muted-foreground">Restaurants</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">10,000+</p>
                <p className="text-sm text-muted-foreground">Daily Orders</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">15 min</p>
                <p className="text-sm text-muted-foreground">Avg Wait Saved</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">4.8★</p>
                <p className="text-sm text-muted-foreground">User Rating</p>
              </div>
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="py-12 text-center space-y-4">
            <h3 className="text-2xl font-bold text-foreground">
              Ready to skip the queue?
            </h3>
            <Link
              href="/restaurants"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors"
            >
              Browse Restaurants
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-8 px-4">
        <div className="max-w-4xl mx-auto text-center text-sm text-muted-foreground">
          <p>curry.io - Skip the Queue, Order Ahead</p>
          <p className="text-xs mt-2">2024 | Made for Uganda</p>
        </div>
      </footer>
    </main>
  );
}
