'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { LogIn } from 'lucide-react';

// Demo restaurants for login
const DEMO_RESTAURANTS = [
  { id: 'nandos-kampala', name: "Nando's Kampala", pin: '1234' },
  { id: 'kfc-kampala', name: 'KFC Kampala', pin: '5678' },
  { id: 'local-rolex-spot', name: 'Mama Bena Rolex & Posho', pin: '9012' },
  { id: 'cafe-java-kampala', name: 'Cafe Java', pin: '3456' },
  { id: 'burger-republic', name: 'Burger Republic', pin: '7890' },
];

export default function AdminLoginPage() {
  const router = useRouter();
  const [selectedRestaurant, setSelectedRestaurant] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedRestaurant) {
      setError('Please select a restaurant');
      return;
    }

    if (!pin) {
      setError('Please enter your PIN');
      return;
    }

    setIsLoading(true);

    // Demo validation
    const restaurant = DEMO_RESTAURANTS.find((r) => r.id === selectedRestaurant);
    if (!restaurant || restaurant.pin !== pin) {
      setError('Invalid PIN. Try: ' + restaurant?.pin);
      setIsLoading(false);
      return;
    }

    // Store session
    if (typeof window !== 'undefined') {
      localStorage.setItem(
        'admin_session',
        JSON.stringify({
          restaurantId: selectedRestaurant,
          restaurantName: restaurant.name,
          loginTime: new Date().toISOString(),
        })
      );
    }

    // Redirect to dashboard
    router.push(`/admin/dashboard?restaurant=${selectedRestaurant}`);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-secondary via-background to-secondary/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            curry.io
          </h1>
          <p className="text-muted-foreground">Kitchen Management</p>
        </div>

        {/* Login Card */}
        <form
          onSubmit={handleLogin}
          className="bg-card border border-border rounded-xl shadow-lg p-8 space-y-6"
        >
          <h2 className="text-2xl font-bold text-foreground text-center">
            Restaurant Login
          </h2>

          {error && (
            <div className="bg-destructive/20 border border-destructive rounded-lg p-3">
              <p className="text-sm text-destructive font-medium">{error}</p>
            </div>
          )}

          {/* Restaurant Selection */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-3">
              Select Your Restaurant
            </label>
            <div className="space-y-2">
              {DEMO_RESTAURANTS.map((restaurant) => (
                <label
                  key={restaurant.id}
                  className="flex items-center p-3 border border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                >
                  <input
                    type="radio"
                    name="restaurant"
                    value={restaurant.id}
                    checked={selectedRestaurant === restaurant.id}
                    onChange={(e) => {
                      setSelectedRestaurant(e.target.value);
                      setError('');
                    }}
                    className="w-4 h-4"
                  />
                  <div className="ml-3">
                    <p className="font-medium text-foreground">
                      {restaurant.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Demo PIN: {restaurant.pin}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* PIN Input */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              PIN Code
            </label>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Enter your PIN"
              className="w-full px-4 py-3 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 text-center text-2xl tracking-widest"
            />
            {selectedRestaurant && (
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Hint: Try{' '}
                <span className="font-mono font-bold">
                  {
                    DEMO_RESTAURANTS.find((r) => r.id === selectedRestaurant)
                      ?.pin
                  }
                </span>
              </p>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading || !selectedRestaurant}
            className="w-full py-3 bg-gradient-to-r from-primary to-accent text-primary-foreground rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <LogIn className="w-5 h-5" />
            {isLoading ? 'Logging in...' : 'Enter Kitchen'}
          </button>

          {/* Info Box */}
          <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4 text-center">
            <p className="text-xs text-blue-900 dark:text-blue-200">
              Demo Mode: Use the PIN shown for any restaurant to login
            </p>
          </div>
        </form>

        {/* Footer Link */}
        <div className="text-center mt-6">
          <Link href="/" className="text-sm text-primary hover:underline">
            Back to curry.io
          </Link>
        </div>
      </div>
    </main>
  );
}
