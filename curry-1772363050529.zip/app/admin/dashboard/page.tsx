'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { getActiveOrders, getRestaurantStats, updateOrderStatus } from '@/lib/store';
import { Order, AdminStats } from '@/lib/types';
import { AdminOrderCard } from '@/components/admin-order-card';
import { LogOut, RefreshCw, TrendingUp, ShoppingCart, CheckCircle, Clock } from 'lucide-react';

export default function AdminDashboardPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const restaurantId = searchParams.get('restaurant') || '';

  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState<AdminStats>({
    totalOrders: 0,
    activeOrders: 0,
    completedOrders: 0,
    totalRevenue: 0,
  });
  const [restaurantName, setRestaurantName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<string>('');

  useEffect(() => {
    // Check auth
    const session = localStorage.getItem('admin_session');
    if (!session) {
      router.push('/admin/login');
      return;
    }

    const sessionData = JSON.parse(session);
    setRestaurantName(sessionData.restaurantName);

    // Load data
    const loadData = () => {
      const activeOrders = getActiveOrders(restaurantId);
      const restaurantStats = getRestaurantStats(restaurantId);

      // Sort by status priority: pending, confirmed, prepping, ready
      const statusPriority = {
        pending: 0,
        confirmed: 1,
        prepping: 2,
        ready: 3,
      };

      const sorted = activeOrders.sort((a, b) => {
        const priorityA = statusPriority[a.status as keyof typeof statusPriority] ?? 99;
        const priorityB = statusPriority[b.status as keyof typeof statusPriority] ?? 99;
        return priorityA - priorityB;
      });

      setOrders(sorted);
      setStats(restaurantStats);
      setLastRefresh(new Date().toLocaleTimeString());
      setIsLoading(false);
    };

    loadData();

    // Auto-refresh every 3 seconds
    const interval = setInterval(loadData, 3000);
    return () => clearInterval(interval);
  }, [restaurantId, router]);

  const handleLogout = () => {
    localStorage.removeItem('admin_session');
    router.push('/admin/login');
  };

  const handleStatusChange = (orderId: string, newStatus: string) => {
    // Update local state immediately for UI feedback
    setOrders((prevOrders) =>
      prevOrders.map((order) =>
        order.id === orderId ? { ...order, status: newStatus as any } : order
      )
    );

    // Reload stats
    const updatedStats = getRestaurantStats(restaurantId);
    setStats(updatedStats);
  };

  const handleRefresh = () => {
    const activeOrders = getActiveOrders(restaurantId);
    setOrders(activeOrders);
    setLastRefresh(new Date().toLocaleTimeString());
  };

  if (isLoading) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading kitchen dashboard...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 bg-secondary text-secondary-foreground border-b border-border z-40">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Kitchen Dashboard</h1>
              <p className="text-sm text-secondary-foreground/70">{restaurantName}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleRefresh}
                className="p-2 hover:bg-secondary-foreground/10 rounded-lg transition-colors"
                title="Refresh"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 bg-secondary-foreground/20 hover:bg-secondary-foreground/30 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                  Active Orders
                </p>
                <p className="text-2xl font-bold text-foreground">
                  {stats.activeOrders}
                </p>
              </div>
              <ShoppingCart className="w-8 h-8 text-primary opacity-30" />
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                  Completed
                </p>
                <p className="text-2xl font-bold text-foreground">
                  {stats.completedOrders}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400 opacity-30" />
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                  Total Orders
                </p>
                <p className="text-2xl font-bold text-foreground">
                  {stats.totalOrders}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-600 dark:text-orange-400 opacity-30" />
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                  Revenue
                </p>
                <p className="text-2xl font-bold text-primary">
                  {(stats.totalRevenue / 1000000).toFixed(1)}M
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-primary opacity-30" />
            </div>
          </div>
        </div>

        {/* Last Refresh */}
        <div className="mb-6 flex items-center justify-between text-xs text-muted-foreground">
          <span>Last refreshed: {lastRefresh}</span>
          <span className="inline-block w-2 h-2 bg-green-600 dark:bg-green-400 rounded-full animate-pulse"></span>
        </div>

        {/* Orders Queue */}
        {orders.length > 0 ? (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Live Order Queue ({orders.length})
            </h2>

            {/* Pending Orders */}
            {orders.filter((o) => o.status === 'pending').length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-yellow-600 dark:text-yellow-400 text-sm uppercase tracking-wide">
                  New Orders
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {orders
                    .filter((o) => o.status === 'pending')
                    .map((order) => (
                      <AdminOrderCard
                        key={order.id}
                        order={order}
                        onStatusChange={handleStatusChange}
                      />
                    ))}
                </div>
              </div>
            )}

            {/* Confirmed Orders */}
            {orders.filter((o) => o.status === 'confirmed').length > 0 && (
              <div className="space-y-3 mt-6">
                <h3 className="font-semibold text-blue-600 dark:text-blue-400 text-sm uppercase tracking-wide">
                  Confirmed
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {orders
                    .filter((o) => o.status === 'confirmed')
                    .map((order) => (
                      <AdminOrderCard
                        key={order.id}
                        order={order}
                        onStatusChange={handleStatusChange}
                      />
                    ))}
                </div>
              </div>
            )}

            {/* Prepping Orders */}
            {orders.filter((o) => o.status === 'prepping').length > 0 && (
              <div className="space-y-3 mt-6">
                <h3 className="font-semibold text-orange-600 dark:text-orange-400 text-sm uppercase tracking-wide">
                  Preparing
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {orders
                    .filter((o) => o.status === 'prepping')
                    .map((order) => (
                      <AdminOrderCard
                        key={order.id}
                        order={order}
                        onStatusChange={handleStatusChange}
                      />
                    ))}
                </div>
              </div>
            )}

            {/* Ready Orders */}
            {orders.filter((o) => o.status === 'ready').length > 0 && (
              <div className="space-y-3 mt-6">
                <h3 className="font-semibold text-green-600 dark:text-green-400 text-sm uppercase tracking-wide">
                  Ready for Pickup
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {orders
                    .filter((o) => o.status === 'ready')
                    .map((order) => (
                      <AdminOrderCard
                        key={order.id}
                        order={order}
                        onStatusChange={handleStatusChange}
                      />
                    ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-12 bg-card border border-border rounded-lg">
            <ShoppingCart className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground">No active orders</p>
            <p className="text-sm text-muted-foreground mt-1">
              Orders will appear here when customers place them
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
