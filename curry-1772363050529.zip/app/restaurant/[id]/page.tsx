'use client';

import { restaurants } from '@/lib/data';
import { MenuItemCard } from '@/components/menu-item-card';
import { MenuItem } from '@/lib/types';
import { addToCart, getCart, getMaxPrepTime } from '@/lib/store';
import Link from 'next/link';
import { ShoppingCart, ArrowLeft, Clock } from 'lucide-react';
import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function RestaurantPage({ params }: PageProps) {
  const router = useRouter();
  const { id } = (params as any);
  const restaurant = restaurants.find((r) => r.id === id);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [cartItems, setCartItems] = useState(getCart()?.items.length ?? 0);

  if (!restaurant) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Restaurant not found</p>
          <Link href="/restaurants" className="text-primary hover:underline">
            Back to restaurants
          </Link>
        </div>
      </div>
    );
  }

  // Get unique categories
  const categories = useMemo(
    () => [...new Set(restaurant.menu.map((item) => item.category))],
    [restaurant.menu]
  );

  // Filter menu items
  const displayMenu = useMemo(() => {
    if (!selectedCategory) return restaurant.menu;
    return restaurant.menu.filter((item) => item.category === selectedCategory);
  }, [selectedCategory, restaurant.menu]);

  const handleAddToCart = (item: MenuItem, quantity: number) => {
    const cartItem = {
      menuItemId: item.id,
      restaurantId: restaurant.id,
      name: item.name,
      price: item.price,
      quantity,
      prepTime: item.prepTime,
    };

    addToCart(restaurant.id, cartItem);
    setCartItems(getCart()?.items.length ?? 0);
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 bg-background/80 backdrop-blur-sm border-b border-border z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          {cartItems > 0 && (
            <Link
              href="/checkout"
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium"
            >
              <ShoppingCart className="w-5 h-5" />
              <span>{cartItems} items</span>
            </Link>
          )}
        </div>
      </nav>

      {/* Restaurant Header */}
      <div className="bg-gradient-to-br from-primary/20 to-accent/20 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">
                {restaurant.name}
              </h1>
              <p className="text-muted-foreground">{restaurant.description}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Est. Ready:</p>
              <div className="flex items-center gap-1 justify-end">
                <Clock className="w-4 h-4 text-primary" />
                <p className="font-bold text-primary">
                  {restaurant.avgPrepTime} min
                </p>
              </div>
            </div>
          </div>

          {/* Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground mb-1">Cuisine</p>
              <p className="font-medium text-foreground">
                {restaurant.cuisineType}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">Rating</p>
              <p className="font-medium text-foreground">★ {restaurant.rating}</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">Hours</p>
              <p className="font-medium text-foreground">
                {restaurant.openingHours}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">Location</p>
              <p className="font-medium text-foreground">{restaurant.location}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Category Filter */}
        <div className="mb-8">
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                selectedCategory === null
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/70'
              }`}
            >
              All Items
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors ${
                  selectedCategory === category
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/70'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items */}
        <div className="grid md:grid-cols-2 gap-4 mb-12">
          {displayMenu.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onAddToCart={handleAddToCart}
            />
          ))}
        </div>

        {/* Continue Shopping */}
        {cartItems > 0 && (
          <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-sm border-t border-border p-4">
            <div className="max-w-4xl mx-auto flex gap-4">
              <button
                onClick={() => router.back()}
                className="flex-1 px-4 py-3 border border-border rounded-lg font-medium hover:bg-muted/50 transition-colors"
              >
                Continue Shopping
              </button>
              <Link
                href="/checkout"
                className="flex-1 px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
              >
                <ShoppingCart className="w-5 h-5" />
                Proceed to Checkout
              </Link>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
