import { Order } from './types';

/**
 * Initialize demo data for pitch purposes
 * Creates sample orders in various states for the admin dashboard
 */
export function initializeDemoData() {
  if (typeof window === 'undefined') return;

  const storageKey = 'curry_orders';
  const existing = localStorage.getItem(storageKey);

  // Only initialize once
  if (existing) {
    try {
      const orders = JSON.parse(existing);
      if (orders.length > 0) return; // Data already exists
    } catch {
      // Continue with initialization
    }
  }

  // Create sample demo orders for the Nando's restaurant
  const now = new Date();
  const demoOrders: Order[] = [
    {
      id: 'demo_1',
      restaurantId: 'nandos-kampala',
      restaurantName: "Nando's Kampala",
      customerName: 'John Musoke',
      customerPhone: '+256 701 111 111',
      items: [
        {
          menuItemId: 'nandos-1/2-chicken-hot',
          restaurantId: 'nandos-kampala',
          name: '1/2 Chicken - Hot',
          price: 38000,
          quantity: 1,
          prepTime: 15,
        },
        {
          menuItemId: 'nandos-garlic-bread',
          restaurantId: 'nandos-kampala',
          name: 'Garlic Bread',
          price: 8000,
          quantity: 2,
          prepTime: 5,
        },
      ],
      totalPrice: 54000,
      status: 'pending',
      orderNumber: 'CRYA1B2C3',
      pickupTime: new Date(now.getTime() + 20 * 60000).toISOString(),
      estimatedReadyTime: new Date(now.getTime() + 15 * 60000).toISOString(),
      createdAt: new Date(now.getTime() - 2 * 60000).toISOString(),
    },
    {
      id: 'demo_2',
      restaurantId: 'nandos-kampala',
      restaurantName: "Nando's Kampala",
      customerName: 'Sarah Kabanda',
      customerPhone: '+256 702 222 222',
      items: [
        {
          menuItemId: 'nandos-full-chicken-xhot',
          restaurantId: 'nandos-kampala',
          name: 'Full Chicken - Extra Hot',
          price: 68000,
          quantity: 1,
          prepTime: 18,
        },
      ],
      totalPrice: 68000,
      status: 'confirmed',
      orderNumber: 'CRYD4E5F6',
      pickupTime: new Date(now.getTime() + 23 * 60000).toISOString(),
      estimatedReadyTime: new Date(now.getTime() + 18 * 60000).toISOString(),
      createdAt: new Date(now.getTime() - 5 * 60000).toISOString(),
    },
    {
      id: 'demo_3',
      restaurantId: 'nandos-kampala',
      restaurantName: "Nando's Kampala",
      customerName: 'David Omondi',
      customerPhone: '+256 703 333 333',
      items: [
        {
          menuItemId: 'nandos-1/4-chicken-mild',
          restaurantId: 'nandos-kampala',
          name: '1/4 Chicken - Mild',
          price: 22000,
          quantity: 3,
          prepTime: 12,
        },
        {
          menuItemId: 'nandos-macho-peas',
          restaurantId: 'nandos-kampala',
          name: 'Macho Peas',
          price: 12000,
          quantity: 1,
          prepTime: 8,
        },
      ],
      totalPrice: 78000,
      status: 'prepping',
      orderNumber: 'CRYG7H8I9',
      pickupTime: new Date(now.getTime() + 15 * 60000).toISOString(),
      estimatedReadyTime: new Date(now.getTime() + 10 * 60000).toISOString(),
      createdAt: new Date(now.getTime() - 8 * 60000).toISOString(),
    },
    {
      id: 'demo_4',
      restaurantId: 'nandos-kampala',
      restaurantName: "Nando's Kampala",
      customerName: 'Grace Nakawa',
      customerPhone: '+256 704 444 444',
      items: [
        {
          menuItemId: 'nandos-chicken-burger',
          restaurantId: 'nandos-kampala',
          name: 'Chicken Pita Burger',
          price: 18000,
          quantity: 2,
          prepTime: 10,
        },
        {
          menuItemId: 'nandos-lemonade',
          restaurantId: 'nandos-kampala',
          name: 'Fresh Lemonade',
          price: 5000,
          quantity: 2,
          prepTime: 2,
        },
      ],
      totalPrice: 46000,
      status: 'ready',
      orderNumber: 'CRYJ0K1L2',
      pickupTime: new Date(now.getTime() - 2 * 60000).toISOString(),
      estimatedReadyTime: new Date(now.getTime() - 5 * 60000).toISOString(),
      createdAt: new Date(now.getTime() - 15 * 60000).toISOString(),
    },
    {
      id: 'demo_5',
      restaurantId: 'kfc-kampala',
      restaurantName: 'KFC Kampala',
      customerName: 'James Okello',
      customerPhone: '+256 705 555 555',
      items: [
        {
          menuItemId: 'kfc-6pc-chicken',
          restaurantId: 'kfc-kampala',
          name: '6-Piece Chicken Bucket',
          price: 45000,
          quantity: 1,
          prepTime: 12,
        },
        {
          menuItemId: 'kfc-coleslaw',
          restaurantId: 'kfc-kampala',
          name: 'Coleslaw',
          price: 6000,
          quantity: 1,
          prepTime: 2,
        },
      ],
      totalPrice: 51000,
      status: 'picked_up',
      orderNumber: 'CRYM3N4O5',
      pickupTime: new Date(now.getTime() - 10 * 60000).toISOString(),
      estimatedReadyTime: new Date(now.getTime() - 15 * 60000).toISOString(),
      createdAt: new Date(now.getTime() - 30 * 60000).toISOString(),
      completedAt: new Date(now.getTime() - 10 * 60000).toISOString(),
    },
  ];

  localStorage.setItem(storageKey, JSON.stringify(demoOrders));
}
