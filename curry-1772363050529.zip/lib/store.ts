'use client';

import { CartItem, Order, OrderStatus } from './types';

const CART_STORAGE_KEY = 'curry_cart';
const ORDERS_STORAGE_KEY = 'curry_orders';
const RESTAURANT_STORAGE_KEY = 'curry_restaurant';

export interface CartStore {
  restaurantId: string;
  items: CartItem[];
}

// Cart Management
export function getCart(): CartStore | null {
  if (typeof window === 'undefined') return null;
  const cart = localStorage.getItem(CART_STORAGE_KEY);
  return cart ? JSON.parse(cart) : null;
}

export function saveCart(cart: CartStore): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
}

export function clearCart(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(CART_STORAGE_KEY);
}

export function addToCart(restaurantId: string, item: CartItem): void {
  const cart = getCart();
  
  if (!cart || cart.restaurantId !== restaurantId) {
    // New restaurant, clear old cart
    saveCart({ restaurantId, items: [item] });
    return;
  }
  
  // Same restaurant, add or update item
  const existingIndex = cart.items.findIndex(
    (i) => i.menuItemId === item.menuItemId
  );
  
  if (existingIndex >= 0) {
    cart.items[existingIndex].quantity += item.quantity;
  } else {
    cart.items.push(item);
  }
  
  saveCart(cart);
}

export function removeFromCart(menuItemId: string): void {
  const cart = getCart();
  if (!cart) return;
  
  cart.items = cart.items.filter((i) => i.menuItemId !== menuItemId);
  
  if (cart.items.length === 0) {
    clearCart();
  } else {
    saveCart(cart);
  }
}

export function updateCartItemQuantity(
  menuItemId: string,
  quantity: number
): void {
  const cart = getCart();
  if (!cart) return;
  
  const item = cart.items.find((i) => i.menuItemId === menuItemId);
  if (item) {
    if (quantity <= 0) {
      removeFromCart(menuItemId);
    } else {
      item.quantity = quantity;
      saveCart(cart);
    }
  }
}

export function getCartTotal(): { items: number; price: number } {
  const cart = getCart();
  if (!cart) return { items: 0, price: 0 };
  
  const items = cart.items.reduce((sum, item) => sum + item.quantity, 0);
  const price = cart.items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  
  return { items, price };
}

export function getMaxPrepTime(): number {
  const cart = getCart();
  if (!cart || cart.items.length === 0) return 0;
  
  return Math.max(...cart.items.map((item) => item.prepTime));
}

// Order Management
export function createOrder(
  restaurantId: string,
  restaurantName: string,
  customerPhone: string,
  customerName: string
): Order {
  const cart = getCart();
  if (!cart || cart.items.length === 0) {
    throw new Error('Cart is empty');
  }
  
  const totalPrice = cart.items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  
  const maxPrepTime = Math.max(...cart.items.map((item) => item.prepTime));
  const now = new Date();
  const estimatedReadyTime = new Date(now.getTime() + maxPrepTime * 60000);
  const pickupTime = new Date(now.getTime() + (maxPrepTime + 5) * 60000);
  
  const orderNumber = `CRY${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
  
  const order: Order = {
    id: `order_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    restaurantId,
    restaurantName,
    customerPhone,
    customerName,
    items: [...cart.items],
    totalPrice,
    status: 'pending',
    pickupTime: pickupTime.toISOString(),
    estimatedReadyTime: estimatedReadyTime.toISOString(),
    createdAt: now.toISOString(),
    orderNumber,
  };
  
  // Save order
  const orders = getAllOrders();
  orders.push(order);
  if (typeof window !== 'undefined') {
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
  }
  
  // Clear cart
  clearCart();
  
  return order;
}

export function getAllOrders(): Order[] {
  if (typeof window === 'undefined') return [];
  const orders = localStorage.getItem(ORDERS_STORAGE_KEY);
  return orders ? JSON.parse(orders) : [];
}

export function getOrder(orderId: string): Order | null {
  const orders = getAllOrders();
  return orders.find((o) => o.id === orderId) || null;
}

export function getOrdersByRestaurant(restaurantId: string): Order[] {
  const orders = getAllOrders();
  return orders.filter((o) => o.restaurantId === restaurantId);
}

export function updateOrderStatus(orderId: string, status: OrderStatus): void {
  const orders = getAllOrders();
  const order = orders.find((o) => o.id === orderId);
  
  if (order) {
    order.status = status;
    if (status === 'picked_up') {
      order.completedAt = new Date().toISOString();
    }
    if (typeof window !== 'undefined') {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    }
  }
}

export function getActiveOrders(restaurantId: string): Order[] {
  const orders = getOrdersByRestaurant(restaurantId);
  return orders.filter(
    (o) => !['picked_up', 'cancelled'].includes(o.status)
  );
}

export function getCustomerOrders(customerPhone: string): Order[] {
  const orders = getAllOrders();
  return orders.filter((o) => o.customerPhone === customerPhone);
}

// Admin Stats
export function getRestaurantStats(restaurantId: string) {
  const orders = getOrdersByRestaurant(restaurantId);
  const activeOrders = orders.filter(
    (o) => !['picked_up', 'cancelled'].includes(o.status)
  );
  const completedOrders = orders.filter((o) => o.status === 'picked_up');
  const totalRevenue = orders.reduce((sum, o) => sum + o.totalPrice, 0);
  
  return {
    totalOrders: orders.length,
    activeOrders: activeOrders.length,
    completedOrders: completedOrders.length,
    totalRevenue,
  };
}
