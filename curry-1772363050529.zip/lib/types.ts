export type OrderStatus = 'pending' | 'confirmed' | 'prepping' | 'ready' | 'picked_up' | 'cancelled';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  prepTime: number; // in minutes
  available: boolean;
  category: string;
  image?: string;
}

export interface Restaurant {
  id: string;
  name: string;
  description: string;
  rating: number;
  cuisineType: string;
  location: string;
  openingHours: string;
  avgPrepTime: number; // average prep time in minutes
  menu: MenuItem[];
  phone?: string;
}

export interface CartItem {
  menuItemId: string;
  restaurantId: string;
  name: string;
  price: number;
  quantity: number;
  prepTime: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  restaurantName: string;
  customerPhone: string;
  customerName: string;
  items: CartItem[];
  totalPrice: number;
  status: OrderStatus;
  pickupTime: string; // ISO format
  estimatedReadyTime: string; // ISO format
  createdAt: string;
  completedAt?: string;
  orderNumber: string; // user-facing order number
}

export interface AdminStats {
  totalOrders: number;
  activeOrders: number;
  completedOrders: number;
  totalRevenue: number;
}
